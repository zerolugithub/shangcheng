CREATE VIEW tp_goods_brand_view AS
	SELECT
		`a`.`id`           AS `id`, `a`.`goods_name` AS `goods_name`, `a`.`goods_price` AS `goods_price`,
		`a`.`goods_thumb`  AS `goods_thumb`, `a`.`goods_ori` AS `goods_ori`, `a`.`goods_count` AS `goods_count`,
		`a`.`goods_sort`   AS `goods_sort`, `a`.`goods_description` AS `goods_description`,
		`a`.`goods_weight` AS `goods_weight`, `a`.`goods_mar_price` AS `goods_mar_price`, `a`.`status` AS `status`,
		`a`.`goods_num`    AS `goods_num`, `a`.`brand_id` AS `brand_id`, `a`.`cate_id` AS `cate_id`,
		`a`.`created_time` AS `created_time`, `a`.`updated_time` AS `updated_time`, `a`.`goods_click` AS `goods_click`,
		`b`.`brand_name`   AS `brand_name`
	FROM (`shop`.`tp_goods` `a` LEFT JOIN `shop`.`tp_brand` `b`
			ON ((`a`.`brand_id` = `b`.`id`)));
